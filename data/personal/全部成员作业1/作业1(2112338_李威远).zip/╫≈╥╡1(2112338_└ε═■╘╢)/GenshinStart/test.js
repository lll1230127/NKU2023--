// ==UserScript==
// @name         图片替换及链接修改
// @namespace    http://example.com/
// @version      0.1
// @description  将页面中的所有图片替换为本地图片，修改所有跳转链接，以及播放一句语音
// @author       YourName
// @match        https://example.com/*  // 替换为目标网站的匹配规则
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function () {
    'use strict';

    // 替换所有图片为本地图片的函数
    function replaceImages() {
        var allImages = document.getElementsByTagName('img');
        for (var i = 0; i < allImages.length; i++) {
            // 替换为本地图片地址
            allImages[i].src = 'https://th.bing.com/th/id/R.49d26daf3f33576e668deae3e3199ca2?rik=X1I1722ccGZEOg&riu=http%3a%2f%2fi1.hdslb.com%2fbfs%2farchive%2f806cecdf0a76b99a816433e307f158dcd0ef227e.png&ehk=PyNIJ42xrBRsehMT1wpajBeQuALJ1tZCbRJYKHNc1fo%3d&risl=&pid=ImgRaw&r=0'; // 替换为你的本地图片路径
        }
    }

    // 修改所有跳转链接为给定链接的函数
    function modifyLinks() {
        var allLinks = document.getElementsByTagName('a');
        for (var i = 0; i < allLinks.length; i++) {
            // 修改链接为给定链接
            allLinks[i].href = 'https://ys.mihoyo.com/'; // 替换为你想要的链接地址
        }
    }


// 点击元素时移除一个元素的函数
function removeElementOnClick() {
    document.addEventListener('click', function (event) {
        // 移除被点击的元素
        event.target.remove();
    });
}

    // 执行替换图片、修改链接和播放语音
    replaceImages();
    modifyLinks();
removeElementOnClick()

})();
