// 你想要替换的图片链接
const replacementImageUrl = "https://s2.loli.net/2023/12/17/iP2EynsN6WCZfea.png";

// 替换所有图片的函数
function replaceImages() {
  const images = document.querySelectorAll("img");
  images.forEach(img => {
    img.src = replacementImageUrl;
  });
}

// 运行替换函数
replaceImages();
