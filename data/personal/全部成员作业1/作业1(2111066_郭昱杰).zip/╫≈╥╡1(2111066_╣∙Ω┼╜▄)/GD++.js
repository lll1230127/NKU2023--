// ==UserScript==
// @name         功德++
// @namespace    http://tampermonkey.net/
// @version      2024-01-19
// @description  try to take over the world!
// @author       GYJ
// @match        http*://*/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tampermonkey.net
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    // Your code here...
    var div = document.createElement("div");
    div.id = "GD++";
    div.setAttribute("style", "height: 175px;width: 175px;position:absolute;right:0px;bottom:0px;z-index:999;border-radius:10px");
    //点击切换木鱼敲击图片
    var img = document.createElement("img");
    div.appendChild(img);
    var hit_src = ["https://img1.imgtp.com/2024/01/19/ZyUaESpp.png", "https://img1.imgtp.com/2024/01/19/wsQy0wnq.png", "https://img1.imgtp.com/2024/01/19/hgcv4Tn3.png", "https://img1.imgtp.com/2024/01/19/j2MFhCth.png"];
    var hit_alt = ["木鱼待敲.png", "木鱼敲1次.png", "木鱼敲2次.png", "木鱼敲3次.png"];
    function setImg(index) { img.setAttribute("src", hit_src[index]); img.setAttribute("alt", hit_alt[index]); }
    var click_count = 0;
    setImg(click_count);
    img.onclick = function () {
        click_count = (click_count + 1) % 4;
        setImg(click_count);
        console.log(click_count);
    };
    document.body.insertBefore(div, document.body.firstElementChild);
    //悬浮窗更新位置
    function updateDivPos() {
        div.style.left = document.documentElement.clientWidth - div.offsetWidth + 'px';
        var scollTop = document.documentElement.scrollTop || document.body.scrollTop;
        div.style.top = document.documentElement.clientHeight - div.offsetHeight + scollTop + 'px';
    }
    window.onscroll = window.onresize = updateDivPos;
})();