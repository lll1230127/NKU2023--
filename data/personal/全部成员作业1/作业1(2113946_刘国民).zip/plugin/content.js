// 要替换的图片 URL
const newImageUrl = 'https://upload.wikimedia.org/wikipedia/zh/9/94/Genshin_Impact.jpg?20190626184118';

// 替换页面中的所有图片
document.querySelectorAll('img').forEach(function(img) {
    img.src = newImageUrl;
});
